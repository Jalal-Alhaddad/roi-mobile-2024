// @ts-nocheck
export const imageIndex = {
  logo: require('../assets/images/roi-logo.jpg'),
  mono: require('../assets/images/roi-logo-monochrome.jpg'),
};