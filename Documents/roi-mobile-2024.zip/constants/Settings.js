
// This file is to store global settings for the app

export default {
  fontSizeModifier: 1,    // Factor by which to increase/decrease font
};